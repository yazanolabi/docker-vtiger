// Extiende la clase base (en este ejemplo se usa Inventory_Detail_Js, que se carga previamente)
Inventory_Detail_Js("SalesOrder_Detail_Custom_Js", {}, {
    /**
     * Método que se ejecuta al registrar eventos en el DetailView
     */
    registerEvents: function() {
        // Llama a la función registerEvents original para mantener la funcionalidad base
        this._super();

        // Obtén el contenedor principal del DetailView usando el método propio de vtiger
        var container = this.getContainer();

        // Si deseas trabajar con selectores al estilo vtiger, puedes construir un array
        // de selectores y unirlos para buscar el elemento deseado.
        var selectors = [];
        // Por ejemplo, queremos ubicar el header de la vista, que tiene la clase .detailview-header
        selectors.push('.detailview-header');

        // Combina los selectores en una cadena (útil si son varios)
        var selectorString = selectors.join(',');
        // Busca el contenedor donde se insertará la nueva fila
        var headerContainer = container.find(selectorString);

        // Crea el HTML de la nueva fila de forma similar a como lo hace vtiger
        var customRow = jQuery('<div class="row detailCustomRow">' +
                                '  <div class="col-sm-12">' +
                                '    <p>Hello World!</p>' +
                                '  </div>' +
                                '</div>');

        // Inserta la nueva fila al final del contenedor encontrado
        headerContainer.append(customRow);

        // Opcional: asigna un evento a la nueva fila usando el estilo de vtiger
        customRow.on('click', function(e) {
            console.log('Se hizo clic en la fila personalizada');
        });
    }
});
